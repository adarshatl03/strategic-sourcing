import React, { createContext, useContext, useState } from 'react';


// Cart Context
export const CartContext = createContext();


// Profile Context
export const ProfileContext = createContext();