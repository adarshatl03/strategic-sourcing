export const API_BASE_URL = 'http://127.0.0.1:8000/api/v1/';
export const PAYPAL_CLIENT_ID = 'test'
export const SERVER_URL = 'http://127.0.0.1:8000/'