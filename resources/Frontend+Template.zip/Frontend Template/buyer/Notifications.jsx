<main className="mt-5">
  <div className="container">
    <section className="">
      <div className="row">
        {/* Sidebar Here */}

        <div className="col-lg-9 mt-1">
          <section className="">
            <main className="mb-5" style={{}}>
              <div className="container px-4">
                <section className="">
                  <h3 className="mb-3">
                    <i className="fas fa-bell" /> Notifications{" "}
                  </h3>
                  <div className="list-group">
                    <a
                      href="#"
                      className="list-group-item list-group-item-action active"
                      aria-current="true"
                    >
                      <div className="d-flex w-100 justify-content-between">
                        <h5 className="mb-1">List group item heading</h5>
                        <small>3 days ago</small>
                      </div>
                      <p className="mb-1">
                        Some placeholder content in a paragraph.
                      </p>
                      <small>And some small print.</small>
                    </a>
                    <a
                      href="#"
                      className="list-group-item list-group-item-action"
                    >
                      <div className="d-flex w-100 justify-content-between">
                        <h5 className="mb-1">List group item heading</h5>
                        <small className="text-muted">3 days ago</small>
                      </div>
                      <p className="mb-1">
                        Some placeholder content in a paragraph.
                      </p>
                      <small className="text-muted">
                        And some muted small print.
                      </small>
                    </a>
                    <a
                      href="#"
                      className="list-group-item list-group-item-action"
                    >
                      <div className="d-flex w-100 justify-content-between">
                        <h5 className="mb-1">List group item heading</h5>
                        <small className="text-muted">3 days ago</small>
                      </div>
                      <p className="mb-1">
                        Some placeholder content in a paragraph.
                      </p>
                      <small className="text-muted">
                        And some muted small print.
                      </small>
                    </a>
                  </div>
                </section>
              </div>
            </main>
          </section>
        </div>
      </div>
    </section>
  </div>
</main>
